<template>
    <div class="dashboard">
        <h1>Dashboard</h1>
    </div>
</template>

<script>
export default {
    
}
</script>